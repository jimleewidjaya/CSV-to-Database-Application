package ocbcadvancedtest.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CsvToDatabaseAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(CsvToDatabaseAppApplication.class, args);
	}

}
